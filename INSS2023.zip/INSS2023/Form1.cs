﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace INSS2023
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Decimal liquido = numericUpDown1.Value;
            Decimal imposto = 0.00m;
            Decimal bruto = 0.00m;
            Decimal aliquota = 0.00m;

            if (liquido.CompareTo(1320.00m) == -1 || liquido.CompareTo(1320.00m) == 0)
            {
                imposto = Math.Round(99.00m,2);
            }
            else if (liquido.CompareTo(1320.00m) == 1 && (liquido.CompareTo(2571.29m) == -1 || liquido.CompareTo(2571.29m) == 0))
            {
                imposto = Math.Round(99.00m + ((liquido - 1320.00m) * 0.09m), 2);
            }
            else if (liquido.CompareTo(2571.29m) == 1 && (liquido.CompareTo(3856.94m) == -1 || liquido.CompareTo(3856.94m) == 0))
            {
                imposto = Math.Round(211.62m + ((liquido - 2571.29m) * 0.12m), 2);
            }
            else if (liquido.CompareTo(3856.94m) == 1 && (liquido.CompareTo(7507.49m) == -1 || liquido.CompareTo(7507.49m) == 0))
            {
                imposto = Math.Round(365.90m + ((liquido - 3856.94m) * 0.14m), 2);
            }
            else
            {
                imposto = Math.Round(876.97m, 2);
            }
            bruto = Math.Round((liquido - imposto), 2);
            aliquota = Math.Round((imposto * 100/liquido), 2);

            label3.Text = imposto.ToString();
            label5.Text = bruto.ToString();
            label7.Text = aliquota.ToString();
        }
    }
}
